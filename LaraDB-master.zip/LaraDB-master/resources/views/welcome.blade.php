<html>
<head>

<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<h1 class="display-1" align="center">Автосалон</h1>
<body style="margin-left: 30%; width: 40%" align="center">
<ul class="list-group" >
  <li class="list-group-item"><a class="list-group-item" href="/brands">Список брендов автомобилей</a></li>
  <li class="list-group-item"><a class="list-group-item" href="/cars">Список автомобилей</a></li>
  <li class="list-group-item"><a class="list-group-item" href="/clients">Список клиентов</a></li>
  <li class="list-group-item"><a class="list-group-item" href="/workers">Список работников</a></li>
  <li class="list-group-item"><a class="list-group-item" href="/orders_cars">Заказы на автомобили</a></li>
  <li class="list-group-item"><a class="list-group-item" href="/workers_orders">Оборот работников</a></li>
</ul>
</body>
</html>
